"""
Trier les fichiers contenus dans le dossier data selon les associations suivantes :
mp3, wav, flac : Musique
avi, mp4, gif : Videos
bmp, png, jpg : Images
txt, pptx, csv, xls, odp, pages : Documents
autres : Divers
"""

from pathlib import Path

extensions = {".mp3" : "Musique",
              ".wav" : "Musique",
              ".flac": "Musique",
              ".avi" : "Videos",
              ".mp4" : "Videos",
              ".gif" : "Videos",
              ".bmp" : "Images",
              ".png" : "Images",
              ".jpg" : "Images",
              ".txt" : "Documents",
              ".pptx" : "Documents",
              ".csv" : "Documents",
              ".xls" : "Documents",
              ".Odp" : "Documents",
              ".pages" : "Documents"}

chemin_programme = Path("/home/madara/Bureau/formation_python/sources/data")
fichiers = [f for f in chemin_programme.iterdir() if f.is_file()]
for f in fichiers:
    dos_final = chemin_programme / extensions.get(f.suffix , "Autres")
    dos_final.mkdir(exist_ok=True)
    f.rename(dos_final/f.name)